<?php

/**
 * @file
 */


namespace BackupMigrate\Core\Destination;


/**
 * Interface RemoteDestinationInterface.
 *
 * @package BackupMigrate\Core\Destination
 */
interface RemoteDestinationInterface extends DestinationInterface {

}
